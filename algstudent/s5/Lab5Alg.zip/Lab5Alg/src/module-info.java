/**
 * 
 */
/**
 * 
 */
module Lab5Alg {
}