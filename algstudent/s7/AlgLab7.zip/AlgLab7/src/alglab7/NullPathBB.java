package alglab7;

import java.util.Random;

public class NullPathBB {
	private static int MinWeight = 10;
	private static int MaxWeight = 99;
	private static int Tol = MaxWeight;
	private int[][] costs;
	private int n;
	private int[] realSol;
	private boolean found = false;
	private boolean[] ds; //nodes to be explored (not used nodes)
	private int bestNode; //to save the final node of the best solution
	private int rootNode; //initial node
	
	public NullPathBB(int n) {
		this.n = n;
		costs = new int[n][n];
		generateCosts(n);
		ds = new boolean[n];
	}
	
	private void generateCosts(int n) {
		for(int i= 0; i<n; i++) {
			for (int j=0; j<n; j++) {
				if(i != j)
				costs[i][j] = generateCost();
			}
		}
	}
	private int generateCost() {
		Random rand = new Random();
		int value = rand.nextInt(MinWeight, MaxWeight);
		if(Math.random() > 0.5) {
			return value;
		}return - value;
	}
	
	private void findNullPathBB(int origin, int target) {
		ds[origin] = true;
		int pruneLimit = Tol + Tol * n-1;
		while(!empty(ds) && estimateBest() < pruneLimit) {
			int node = extractBestNode(ds);
			int[] children = getValidChildren(node);
			for(int i = 0; i<children.length;i++) {
				if(children[i] != target) {
					if(isSolution(sol, children[i])) {
						int cost
					}
					else {
						getHeuristicValue()
					}
				}
				
			}
			
		}
		
	}
	
	
	private int chooseNode() {
		// TODO Auto-generated method stub
		return 0;
	}

	private boolean isSolution(int[] sol, int count) {
	    boolean[] visited = new boolean[n];
	    for (int i = 0; i < count; i++) {
	        if (visited[sol[i]]) {
	            return false; 
	        }
	        visited[sol[i]] = true;
	    }
	    
	    int totalCost = 0;
	    for (int i = 0; i < count - 1; i++) {
	        totalCost += costs[sol[i]][sol[i + 1]]; 
	    }
	    
	    return totalCost >= -MaxWeight && totalCost <= MaxWeight;
	}
	
	private boolean empty(boolean[] ds) {
		for(int i=0; i<n;i++) {
			if(ds[i])
				return false;
		}
		return true;
	}
	
	public int extractBestNode(boolean[] ds) {
		return 0;
	}
	public int estimateBest() {
		
		return 0;
	}
}
