/**
 * 
 */
/**
 * 
 */
module alglab7 {
}