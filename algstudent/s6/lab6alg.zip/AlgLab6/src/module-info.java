/**
 * 
 */
/**
 * 
 */
module AlgLab6 {
}