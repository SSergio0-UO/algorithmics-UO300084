package lab6;


public class NullPathTimes {
	public static void main(String arg[]) {
		long t1, t2;
		NullPath mp;
//		for(int i = 20; i < Integer.MAX_VALUE; i+=5) {
//			t1 = System.currentTimeMillis();
//			mp = new NullPath(i);
//			t2 = System.currentTimeMillis();
//			System.out.println("Time for " + i + ":\t" + (t2 - t1));
//		}
		mp = new NullPath(3);
	}
}
