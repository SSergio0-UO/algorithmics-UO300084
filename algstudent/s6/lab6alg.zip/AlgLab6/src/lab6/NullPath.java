package lab6;

import java.util.Random;

public class NullPath {
	private static int MinWeight = 10;
	private static int MaxWeight = 99;
	private int[][] costs;
	private int[] realSol;
	private int n;
	private boolean found = false;
	
	public NullPath(int n) {
		this.n = n;
		costs = new int[n][n];
		generateCosts(n);
		printMatrix(costs);
		findNullPath(0,n-1);
		if(found) {
			for(int i=0; i<realSol.length; i++) {
				System.out.print(realSol[i] + "-");
			}
		}
		
	}
	
	private void generateCosts(int n) {
		for(int i= 0; i<n; i++) {
			for (int j=0; j<n; j++) {
				if(i != j)
				costs[i][j] = generateCost();
			}
		}
	}
	private int generateCost() {
		Random rand = new Random();
		int value = rand.nextInt(MinWeight, MaxWeight);
		if(Math.random() > 0.5) {
			return value;
		}return - value;
	}
	
	static void printMatrix(int[][] a) {
		int n = a.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print(String.format("%10s", a[i][j]));
			System.out.println();
		}
		System.out.println();
	}
	
	private void findNullPath(int origin, int target) {
	    int[] sol = new int[n];
	    sol[0] = origin; 
	    boolean[] visited = new boolean[n]; 
	    visited[origin] = true; 
	    findNullPath(sol, 1, visited);
	}
	private void findNullPath(int[] sol, int count, boolean[] visited) {
	    if (count == n) {
	        if (isSolution(sol, count)) {
	            found = true;
	            realSol = sol.clone();
	        }
	        return;
	    }
	    
	    for (int i = 0; i < n; i++) {
	        if (!visited[i]) {
	            sol[count] = i; 
	            visited[i] = true; 
	            findNullPath(sol, count + 1, visited); 
	            visited[i] = false; 
	            if (found) {
	                return;
	            }
	        }
	    }
	}
	
	private boolean isSolution(int[] sol, int count) {
	    boolean[] visited = new boolean[n];
	    for (int i = 0; i < count; i++) {
	        if (visited[sol[i]]) {
	            return false; 
	        }
	        visited[sol[i]] = true;
	    }
	    
	    int totalCost = 0;
	    for (int i = 0; i < count - 1; i++) {
	        totalCost += costs[sol[i]][sol[i + 1]]; 
	    }
	    
	    return totalCost >= -MaxWeight && totalCost <= MaxWeight;
	}
}
