package lab6;

import java.util.Random;

public class NullPath {
	private static int MinWeight = 10;
	private static int MaxWeight = 99;
	private int[][] costs;
	private int[] realSol;
	private int n;
	private boolean found = false;
	
	public NullPath(int n) {
		this.n = n;
		costs = new int[n][n];
		generateCosts(n);
		printMatrix(costs);
		findNullPath(0,n-1);
		if(found) {
			for(int i=0; i<realSol.length; i++) {
				System.out.print(realSol[i] + "-");
			}
		}
		
	}
	private void  findNullPath(int origin, int target) {
		int [] sol = new int[n];
		sol[0] = origin;
		findNullPath( sol, 1);
		
	}
	private void findNullPath( int[] sol, int count) {
		if(isSolution(sol)) {
			found = true;
			realSol = sol;
		}
		if(!found) {
			for(int i = 0; i<n; i++) {
				if(count < n) {
					sol[count] = i;
					findNullPath(sol, count+1);
				}
			}
		}
	}
	private void generateCosts(int n) {
		for(int i= 0; i<n; i++) {
			for (int j=0; j<n; j++) {
				if(i != j)
				costs[i][j] = generateCost();
			}
		}
	}
	private int generateCost() {
		Random rand = new Random();
		int value = rand.nextInt(MinWeight, MaxWeight);
		if(Math.random() > 0.5) {
			return value;
		}return - value;
	}
	private int getCost(int[] sol) {
		int sum = 0;
		for(int i = 0; i < n-1; i++) {
			sum += costs[sol[i]][sol[i+1]];
		}
		return sum;
	}
	private boolean isSolution(int[] sol) {
		int sum= getCost(sol);
		
		for(int i = 0; i<n; i++) {
			for (int j = 0; j<n; j++) {
				if(i != j)
					if(sol[i] == sol[j])
						return false;
			}
		}
		
		if(sum < MaxWeight && sum > -MaxWeight) {
			return true;
		}return false;
	}
	
	static void printMatrix(int[][] a) {
		int n = a.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print(String.format("%10s", a[i][j]));
			System.out.println();
		}
		System.out.println();
	}
}
