/**
 * 
 */
/**
 * 
 */
module Lab1_2_Alg {
}