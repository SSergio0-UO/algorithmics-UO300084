/**
 * 
 */
/**
 * 
 */
module Lab3 {
}