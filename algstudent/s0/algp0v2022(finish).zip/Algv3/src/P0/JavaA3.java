package P0;

import java.util.ArrayList;

public class JavaA3 {

	public static boolean primoA3(int m) {
		for (int i=2; i<m / 2;i++) {
			if(m%2==0) {
				return false;
			}
		}
		return true;
	}
	
	public static ArrayList listadoPrimos(int n) {
		ArrayList<Integer> primes = new ArrayList<>();
		for(int i=2; i<n; i++) {
			if(primoA3(i)) {
				primes.add(i);
			}
		}
		return primes;
	}
	
	public static void main(String[] args) {
		int n = 10000;
		for(int i=0; i<7; i++) {
			
	        long startTime = System.nanoTime();
	        listadoPrimos(n);
	        long endTime = System.nanoTime();
	        long duration = endTime - startTime;
	        System.out.println("Elapsed time in miliseconds for " + n + " iterations : " + duration / 1000000 +" ms");
	        n = n*2;
		}
		
	}
}
