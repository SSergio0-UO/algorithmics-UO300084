package P0;

public class JavaA1 {
		

	public static void main(String[] args) {
		int n = 10000;
		for(int i=0; i<7; i++) {
			
	        long startTime = System.nanoTime();
	        JavaA1v1 ja1v1 = new JavaA1v1();
	        ja1v1.listadoPrimos(n);
	        long endTime = System.nanoTime();
	        long duration = endTime - startTime;
	        System.out.println("Elapsed time in miliseconds for " + n + " iterations : " + duration / 1000000 +" ms");
	        n = n*2;
		}
		
	}

}