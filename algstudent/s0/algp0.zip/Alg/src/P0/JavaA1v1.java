package P0;

import java.util.ArrayList;

public class JavaA1v1 {

	public ArrayList listadoPrimos(int n) {
		JavaA1v0 ja1v0 = new JavaA1v0();
		ArrayList<Integer> primes = new ArrayList<>();
		for(int i=2; i<n; i++) {
			if(ja1v0.primoA1(i)) {
				primes.add(i);
			}
		}
		return primes;
	}
}
