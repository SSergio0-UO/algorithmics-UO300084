/**
 * 
 */
/**
 * 
 */
module Lab2 {
}